function countQuery(input, query) {
  return query.map(q =>
    input.reduce((acc, curr) => acc + (curr === q ? 1 : 0), 0)
  );
}

const INPUT = ['xc', 'dz', 'bbb', 'dz'];
const QUERY = ['bbb', 'ac', 'dz'];

const OUTPUT = countQuery(INPUT, QUERY);
console.log(OUTPUT);