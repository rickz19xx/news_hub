function reverseAlphabetsKeepNumber(str) {
  const letters = str.slice(0, -1);
  const number = str.slice(-1);
  const reversedLetters = letters.split('').reverse().join('');
  return reversedLetters + number;
}

const input = "NEGIE1";
const output = reverseAlphabetsKeepNumber(input);
console.log(output);